import java.io.*;
import java.lang.String;
import java.lang.System;
import java.util.*;


public class Formula1ChampionshipTester {
    public static void main(String[] args) throws IOException {
        Formula1ChampionshipManager a1=new Formula1ChampionshipManager(5,5);
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("1.Add");
            System.out.println("2.Display of this race");
            System.out.println("3.Search");
            System.out.println("4.Delete");
            System.out.println("5.Update");
            System.out.println("6.Add race");
            System.out.println("7.Sort");
            System.out.println("8.Table");
            System.out.println("9.Statistics");
            System.out.println("0.Exit");
            System.out.print("Enter Your Choice : ");
            choice = sc.nextInt();
            switch (choice) {
                case 1 -> a1.AddDriver();
                case 2 -> a1.Display();
                case 3 -> a1.SearchDriver();
                case 4 -> a1.DeleteDriver();
                case 5 -> {a1.ChangeDriver(); break;}
                case 6 -> a1.addRace();
                case 7 -> a1.Sort();
                case 8 -> a1.displayTable();
                case 9 -> a1.displayStatistics();
                case 0 -> System.exit(0);
                default -> throw new IllegalStateException("Unexpected value: " + choice);
            }
        }
        while (choice != 0) ;
    }
}
