import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
class pointscom implements Comparator<Formula1Driver>
{
    @Override
    public int compare(Formula1Driver f1, Formula1Driver f2) {
        return f2.getTotalPoints()- f1.getTotalPoints();
    }
}

public class SortTextFile
{
    public static void main(String[] args)throws IOException
    {
        Formula1ChampionshipManager FF=new Formula1ChampionshipManager();
        FF.AddDriver();
        FF.addRace();

        BufferedReader reader = new BufferedReader(new FileReader("t.txt"));

        String currentLine = reader.readLine();

        while (currentLine != null)
        {
            String[] a = currentLine.split(",");

            //Creating Student object for every student record and adding it to ArrayList

            currentLine = reader.readLine();
        }

        //Sorting ArrayList studentRecords based on marks

        Collections.sort(Formula1ChampionshipManager.list, new pointscom());

        //Creating BufferedWriter object to write into output text file

        BufferedWriter writer = new BufferedWriter(new FileWriter("abc.txt"));

        //Writing every studentRecords into output text file

        for (Formula1Driver f : Formula1ChampionshipManager.list)
        {
            writer.write(f.getName());

            writer.write(","+f.getLocation()+","+f.getTeam()+","+f.getRaces()+","+f.getTotalPoints()+","+f.getFirstpositions()+","+f.getSecondpositions()+","+f.getThirdpositions());

            writer.newLine();
        }

        //Closing the resources

        reader.close();

        writer.close();



    }
}