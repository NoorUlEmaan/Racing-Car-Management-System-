import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.sql.Timestamp;
import java.util.*;
import java.util.List;
import com.bethecoder.ascii_table.ASCIITable;

import javax.swing.*;

import static javax.swing.text.html.HTML.Tag.I;

public class Formula1ChampionshipManager extends Formula1Driver implements ChampionshipManager,Serializable {
    private int no_of_cars;
    private int no_of_drivers;
    private static int no_of_races = 0;
    private int FirstPosition = 0;
    private int SecondPosition = 0;
    private int ThirdPosition = 0;
    private int current_points;
    ArrayList<Integer> ii=new ArrayList();
    Scanner sc = new Scanner(System.in);
    static ArrayList<Formula1Driver> list = new ArrayList<>();

    //Constructors

    public Formula1ChampionshipManager(int no_of_cars, int no_of_drivers) {
        super();
        this.no_of_cars = no_of_cars;
        this.no_of_drivers = no_of_drivers;
    }

    public Formula1ChampionshipManager() {
    }

    //Getters and Setters

    public int getNo_of_cars() {
        return no_of_cars;
    }

    public void setNo_of_cars(int no_of_cars) {
        this.no_of_cars = no_of_cars;
    }

    public int getNo_of_drivers() {
        return no_of_drivers;
    }

    public void setNo_of_drivers(int no_of_drivers) {
        this.no_of_drivers = no_of_drivers;
    }

    public int getNo_of_races() {
        return no_of_races;
    }

    public void setNo_of_races(int no_of_races) {
        Formula1ChampionshipManager.no_of_races = no_of_races;
    }

    public int getFirstPosition() {
        return FirstPosition;
    }

    public void setFirstPosition(int firstPosition) {
        FirstPosition = firstPosition;
    }

    public int getSecondPosition() {
        return SecondPosition;
    }

    public void setSecondPosition(int secondPosition) {
        SecondPosition = secondPosition;
    }

    public int getThirdPosition() {
        return ThirdPosition;
    }

    public void setThirdPosition(int thirdPosition) {
        ThirdPosition = thirdPosition;
    }

    public int getCurrent_points() {
        return current_points;
    }

    public void setCurrent_points(int current_points) {
        this.current_points = current_points;
    }

    //Defining abstract functions of interface

    @Override
    public void AddDriver() throws IOException {
        BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt", true));
        Scanner strInput = new Scanner(System.in);
        Scanner sc2 = new Scanner(System.in);

        String name;
        String location;
        String team;
        boolean found=false;
        System.out.print("How many Drivers you want to add : ");
        int n = sc2.nextInt();
        for (int i = 0; i < n; i++) {
            System.out.print("Enter the Driver Name: ");
            name = strInput.nextLine();
            super.setName(name);

            System.out.print("Enter the Driver Location: ");
            location = strInput.nextLine();
            super.setLocation(location);

            System.out.print("Enter the Driver Team: ");
            team = strInput.nextLine();
            super.setTeam(team);
            super.setRaces(getNo_of_races());
            super.setFirstpositions(getFirstpositions());
            super.setSecondpositions(getSecondpositions());
            super.setThirdpositions(getThirdpositions());
            for (Formula1Driver dd:list){
                if(dd.getName()==name){
                    found=true;
                    break;
                }
            }
            System.out.println(found);
            if (found){
                System.out.println("team already exist");
            }
            else {
            Formula1Driver d1 = new Formula1Driver(getName(), getLocation(), getTeam(), getTotalPoints(), getNo_of_races(), getFirstpositions(), getSecondpositions(), getThirdpositions());
            list.add(d1);
            d1.setProbability(0);
            bw.write(d1.getId() - 1 + "," + d1.getName() + "," + d1.getLocation() + "," + d1.getTeam() + "," + d1.getTotalPoints() + "," + d1.getRaces() + "," + d1.getFirstpositions() + "," + d1.getSecondpositions() + "," + d1.getThirdpositions() + "," + d1.getProbability());
            bw.flush();
            bw.newLine();
        }}
        bw.close();
    }

    @Override
    public void DeleteDriver() throws IOException {
            String name, record;
            File tempDB = new File("temp.txt");
            File db = new File("output.txt");

            BufferedReader br = new BufferedReader(new FileReader(db));
            BufferedWriter bw = new BufferedWriter(new FileWriter(tempDB));


            System.out.println("Enter the Driver Name : ");
            name = sc.nextLine();

            while ((record = br.readLine()) != null) {
                if (record.contains(name)){
                    continue;}
                System.out.println(record);

                bw.write(record);
                bw.flush();
                bw.newLine();

            }

            br.close();
            bw.close();

            db.delete();

            tempDB.renameTo(db);

            for (Formula1Driver d: list){
                if(d.getName()==name){
                    list.remove(d);
                 }
            }
        System.out.println(list);

    }

    @Override
    public void ChangeDriver() throws IOException {
        System.out.println("Enter the team: ");
        String team = sc.nextLine();
        Scanner neww =new Scanner(System.in);
        for(Formula1Driver f : list){
            if (f.getTeam()==team)
                System.out.println("Enter the new driver : ");
                String name = neww.nextLine();
                f.setName(name);
                System.out.println(f);
        }
    }

        @Override
        public void SearchDriver() throws IOException {
            String name, record;
            BufferedReader br = new BufferedReader(new FileReader("output.txt"));
            System.out.println("Enter the Driver Name : ");
            name = sc.nextLine();
            while ((record = br.readLine()) != null) {
                if (record.contains(name)) {
                    System.out.println(record);
                }
            }
            System.out.println(" ------------------------------------------------------------- ");

            br.close();
        }


        public void abc () throws IOException{
            String record;
            BufferedReader br = new BufferedReader(new FileReader("hh.txt"));
            BufferedWriter bw = new BufferedWriter(new FileWriter("searching.txt"));
            PrintWriter pw=new PrintWriter(bw,true);
            while ((record = br.readLine()) != null) {
                    pw.println(record);
                }
            }

    @Override
    public void SearchDriver2(String name) throws IOException {
        String record;

        BufferedReader br = new BufferedReader(new FileReader("abcc.txt"));
        BufferedWriter bw = new BufferedWriter(new FileWriter("searching.txt"));
        PrintWriter pw=new PrintWriter(bw,true);
        while ((record = br.readLine()) != null) {
               String[] a=record.split(",");
               String[] B=a[0].split(":");
               System.out.println(B[1]);
               if ((B[1].replaceAll("\\s+","").equals(name.replaceAll("\\s+","")))) {
                   System.out.println("Equals"+B[1]);
                   pw.println(record);
               }
        }
    }

    @Override
    public void displayTable() throws IOException {
        System.out.println(" ------------------------------------------------------------- ");
        System.out.println("|	Name   Location	 Team   Points   |");
        System.out.println(" ------------------------------------------------------------- ");
        for (Formula1Driver d:list){
            System.out.println(d);
        }
        System.out.println(" ------------------------------------------------------------- ");
        }

    public void displayStatistics() {
        System.out.println("Enter the name of the driver :  ");
        String name = sc.next();
        for (Formula1Driver driver : list) {
            if (name.equals(driver.getName())) {
                System.out.println( "\nNumber of first positions: " + driver.getFirstpositions() +
                        "\nNumber of second positions: " + driver.getSecondpositions() +
                        "\nNumber of third positions: " + driver.getThirdpositions() +
                        "\nTotal number of points: " + driver.getTotalPoints());
            }
        }
    }

    @Override
    public void Display() {
        System.out.println("------------------");
        for (Formula1Driver d : list) {
            System.out.println(d.toString());
        }
        System.out.println("------------------");
    }




    @Override
    public void Sort() {

        list.sort((o1, o2) -> o2.getTotalPoints() - o1.getTotalPoints());
        System.out.println(list);
    }


    public void Sort2() {
        ArrayList<Integer> ai=new ArrayList();
        GUI.dri.sort((o1, o2) -> o2.getTotalPoints() - o1.getTotalPoints());
    }


    public void proPart1() {
        Sort2();
        ArrayList<Integer> kk=new ArrayList<>();
        for (int i =10;i<GUI.dri.size();i++){
            GUI.dri.get(i).setProbability(0);
        }
        for (int i =0;i<4;i++){
            int a= GUI.dri.get(i).getTotalPoints()+GUI.dri.get(i).getFirstpositions();
            kk.add(a);
        }
        Collections.sort(kk);
        for (Integer jj: kk){

        }


    }

    public void sort3(){
        new SortTextFile();
    }
    @Override
    public void DisplayParticularDriver() throws FileNotFoundException {
        System.out.println("Enter the name of the driver: ");
        String name5 = sc.next();
        BufferedReader reader = new BufferedReader(new FileReader("t.txt"));
        for (Formula1Driver d : list) {
            if (name5.equals(d.getName())) {
                System.out.println("Races : " + d.getRaces() +
                        "\nNumber of first positions: " + d.getFirstpositions() +
                        "\nNumber of second positions: " + d.getSecondpositions() +
                        "\nNumber of third positions: " + d.getThirdpositions() +
                        "\nNumber of points: " + d.getTotalPoints());
            }
        }
    }

    @Override
    public void PositionArray() {
        list.sort((o1, o2) -> o2.getTotalPoints() - o1.getTotalPoints());
        System.out.println("Enter the number of positions you want to show");
        int size = sc.nextInt();
        StringBuilder fullArray = new StringBuilder("[ ");
        int[] positionArray = new int[size];
        int j = 0;
        for (Formula1Driver d : list) {
            positionArray[j] = d.getTotalPoints();
            j++;
            if (j == size) {
                break;
            }
        }
        for (int i = 1; i < positionArray.length; i++) {
            String a = i + ":" + positionArray[i - 1] + ", ";
            fullArray.append(a);
        }
        fullArray.append(positionArray.length).append(":").append(positionArray[positionArray.length - 1]);
        fullArray.append(" ]");
        System.out.println(fullArray);
    }

    public void Display2() throws IOException {
        File aa = new File("th.txt");
        BufferedWriter bw3=new BufferedWriter(new FileWriter(aa));
        System.out.println("------------------");
        for (Formula1Driver d : list) {
            System.out.println(d.toString());
            bw3.write(String.valueOf(d));

    }
        System.out.println("------------------");
}
    @Override
    public void addRace() throws IOException {
        setNo_of_races(no_of_races++);
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        for (Formula1Driver driver : list) {
            driver.setTime(Timestamp.valueOf(timestamp.toString()));
            int racePosition = (int) ((Math.random() * (9)) + 1);
            String[] driverDetails={};
            switch (racePosition) {
                case 1:
                    driver.setPoints_per_race(25);
                    FirstPosition++;
                    driver.setFirstpositions(FirstPosition);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);    changing(driver);
                    System.out.println("points are"+driver.getTotalPoints());
                    driver.setProbability(40);
                    break;
                case 2:
                    driver.setPoints_per_race(18);
                    SecondPosition++;
                    driver.setSecondpositions(SecondPosition);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(30);
                    break;
                case 3:
                    driver.setPoints_per_race(15);
                    ThirdPosition++;
                    driver.setThirdpositions(ThirdPosition);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(10);
                    break;
                case 4:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(10);
                    break;
                case 5:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(2);
                    break;
                case 6:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(2);
                    break;
                case 7:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(2);
                    break;
                case 8:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(2);
                    break;
                case 9:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(2);
                    break;
                case 10:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() + driver.getPoints_per_race();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    driver.setProbability(0);
                    break;
            }
        }
    }

    public void changing(Formula1Driver d) throws IOException {
        FileWriter writer = new FileWriter("output.txt");
        FileWriter writer2 = new FileWriter("hh.txt");
        for(Formula1Driver dd: list) {
            writer.write(dd + System.lineSeparator());
        }
        writer.close();
    }

    public void addRace2() throws IOException {
        setNo_of_races(no_of_races++);
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        for (Formula1Driver driver : list) {
            driver.setTime(Timestamp.valueOf(timestamp.toString()));
            int racePosition = (int) ((Math.random() * (9)) + 1);
            switch (racePosition) {
                case 1:
                    driver.setPoints_per_race(25);
                    FirstPosition++;
                    driver.setFirstpositions(FirstPosition);
                    current_points = driver.getTotalPoints();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);    changing(driver);
                    System.out.println("points are"+driver.getTotalPoints());
                    break;
                case 2:
                    driver.setPoints_per_race(18);
                    SecondPosition++;
                    driver.setSecondpositions(SecondPosition);
                    current_points = driver.getTotalPoints();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 3:
                    driver.setPoints_per_race(15);
                    ThirdPosition++;
                    driver.setThirdpositions(ThirdPosition);
                    current_points = driver.getTotalPoints();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 4:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 5:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() ;
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 6:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 7:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() ;
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 8:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints() ;
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 9:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
                case 10:
                    driver.setPoints_per_race(12);
                    current_points = driver.getTotalPoints();
                    driver.setTotalPoints(current_points);
                    driver.setRaces(no_of_races);
                    System.out.println("points are"+driver.getTotalPoints());
                    changing(driver);
                    break;
            }
        }
    }

    public void changing2(Formula1Driver d) throws IOException {
        FileWriter writer = new FileWriter("output.txt");
        FileWriter writer2 = new FileWriter("hh.txt");
        for(Formula1Driver dd: list) {
            writer.write(dd + System.lineSeparator());
            writer2.write(dd + System.lineSeparator());

        }
        writer.close();
        writer2.close();
    }


    @Override
    public int getNoOfDrivers() {
        return no_of_drivers;
    }

    @Override
    public int getOfCars() {
        return no_of_drivers;
    }

    public static void main(String[] args) throws IOException {
        Formula1ChampionshipManager ff=new Formula1ChampionshipManager();
        ff.SearchDriver2("y");
        ff.AddDriver();
        ff.AddDriver();
    }
}