import java.io.FileNotFoundException;
import java.io.IOException;

public interface ChampionshipManager {
    void AddDriver() throws IOException;
    void DeleteDriver() throws IOException;
    void ChangeDriver() throws IOException;
    void SearchDriver() throws IOException;
    void SearchDriver2(String name) throws IOException;    //for gui
    void Display();
    void Sort() throws IOException;
    void DisplayParticularDriver() throws FileNotFoundException;
    void PositionArray();
    void displayStatistics();
    void displayTable() throws IOException;
    void addRace() throws IOException;
    int getNoOfDrivers();
    int getOfCars();
}
