import org.jetbrains.annotations.NotNull;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.nio.channels.FileChannel;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;

public class GUI extends Formula1ChampionshipTester implements ActionListener {
    private static int ii=0;
    public static ArrayList<Formula1Driver> dri =new ArrayList<>();
    JButton b,b0,b1,b4,B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12,B13,B14,B15,B16,BB1,BB2;
    JFrame f,f1,f2,f3,f4,f5,f6,f7,f8,f9,f10;
    JLabel l,l2,l3,id,id15,id16,id3,id19,id8,id1,id2,id4;
    JTextField t,t1,t2,t3,t4;

    public void firstpage(){
            f=new JFrame(" Formula1 Championship ");
            f.setBackground(Color.red);
            f.setLayout(null);

            ImageIcon i1 = new ImageIcon("car2.jpg");
            Image i2 = i1.getImage().getScaledInstance(1000,600,Image.SCALE_DEFAULT);
            ImageIcon i3 = new ImageIcon(i2);
            JLabel l1 = new JLabel(i3);

            l1.setBounds(0,150,1360,530);
            f.add(l1);


            b = new JButton("CLICK HERE TO CONTINUE");
            b.setBackground(Color.BLACK);
            b.setForeground(Color.WHITE);


            b.setBounds(500,600,300,70);
            b.addActionListener(this);

            id=new JLabel();
            id.setBounds(0,0,1360,750);
            id.setLayout(null);



            JLabel lid=new JLabel("FORMULA1 CHAMPIONSHIP ");
            lid.setBounds(80,30,1500,100);
            lid.setFont(new Font("serif",Font.PLAIN,70));
            lid.setForeground(Color.red);
            id.add(lid);

            id.add(b);
            f.add(id);


            f.getContentPane().setBackground(Color.WHITE);

            f.setVisible(true);
            f.setSize(1300,750);
            f.setLocation(10,10);
            f.setResizable(false);

            while(true){
                lid.setVisible(false); // lid =  j label
                try{
                    Thread.sleep(500); //1000 = 1 second
                }catch(Exception e){}
                lid.setVisible(true);
                try{
                    Thread.sleep(500);
                }catch(Exception e){}
            }}

    public void Add_Race() {

        f3 = new JFrame(" Formula1 Championship ");
        f3.setBackground(Color.red);
        f3.setLayout(null);

        ImageIcon i1 = new ImageIcon("car2.jpg");
        Image i2 = i1.getImage().getScaledInstance(1000, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l1 = new JLabel(i3);

        l1.setBounds(0, 150, 1360, 530);
        f3.add(l1);


        b4 = new JButton("Display Table");
        b4.setBackground(Color.BLACK);
        b4.setForeground(Color.WHITE);


        b4.setBounds(500, 600, 300, 70);
        b4.addActionListener(this);

        id4 = new JLabel();
        id4.setBounds(0, 0, 1360, 750);
        id4.setLayout(null);


        JLabel lid = new JLabel(" RACE STARTED :) ");
        lid.setBounds(80, 30, 1500, 100);
        lid.setFont(new Font("serif", Font.PLAIN, 70));
        lid.setForeground(Color.red);
        id4.add(lid);

        id4.add(b4);
        f3.add(id4);


        f3.getContentPane().setBackground(Color.WHITE);

        f3.setVisible(true);
        f3.setSize(1300, 750);
        f3.setLocation(10, 10);
        f3.setResizable(false);

    }
        public void Add_driver(){
        f4 = new JFrame("Add Driver");
        f4.setBackground(Color.white);
        f4.setLayout(null);

        id19=new JLabel();
        id19.setBounds(10,10,1300,750);
        id19.setLayout(null);
        ImageIcon img = new ImageIcon("car3.jpg");
        id19.setIcon(img);

        id8 = new JLabel("New Driver Details");
        id8.setBounds(320,30,500,50);
        id8.setFont(new Font("serif",Font.ITALIC,25));
        id8.setForeground(Color.black);
        id19.add(id8);
        f4.add(id19);


        id1 = new JLabel("Name");
        id1.setBounds(50,150,100,30);
        id1.setFont(new Font("serif",Font.BOLD,20));
        id19.add(id1);

        t1=new JTextField();
        t1.setBounds(200,150,150,30);
        id19.add(t1);

        id2 = new JLabel("Team");
        id2.setBounds(50,250,200,30);
        id2.setFont(new Font("serif",Font.BOLD,20));
        id19.add(id2);

        t2=new JTextField();
        t2.setBounds(200,250,150,30);
        id19.add(t2);

        id3= new JLabel("Location");
        id3.setBounds(50,200,100,30);
        id3.setFont(new Font("serif",Font.BOLD,20));
        id19.add(id3);

        t3=new JTextField();
        t3.setBounds(200,200,150,30);
        id19.add(t3);


        b0 = new JButton("Submit");
        b0.setBackground(Color.BLACK);
        b0.setForeground(Color.WHITE);
        b0.setBounds(250,550,150,40);

        id19.add(b0);

        b1=new JButton("Back");
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setBounds(450,550,150,40);

        id19.add(b1);

        b0.addActionListener(this);
        b1.addActionListener(this);

        f4.setVisible(true);
        f4.setSize(1300,750);
        f4.setLocation(10,10);
    }

    public void secondpage(){
            f1 = new JFrame("Formula1 Championship");
            f1.setBackground(Color.white);
            f1.setLayout(null);

            id15=new JLabel();
            id15.setBounds(10,10,1300,750);
            id15.setLayout(null);
            ImageIcon img = new ImageIcon("car3.jpg");
            id15.setIcon(img);


            B1 = new JButton("Generate a race");
            B1.setBackground(Color.BLACK);
            B1.setForeground(Color.WHITE);
            B1.setBounds(50,150,150,40);

            id15.add(B1);

            B3=new JButton("Display");
            B3.setBackground(Color.BLACK);
            B3.setForeground(Color.WHITE);
            B3.setBounds(50,250,150,40);

            id15.add(B3);



            B2=new JButton("Statistics");
            B2.setBackground(Color.BLACK);
            B2.setForeground(Color.WHITE);
            B2.setBounds(250,150,150,40);

            id15.add(B2);


            B4=new JButton("Search");
            B4.setBackground(Color.BLACK);
            B4.setForeground(Color.WHITE);
            B4.setBounds(250,250,150,40);

            id15.add(B4);

            BB1=new JButton("Back");
            BB1.setBackground(Color.BLACK);
            BB1.setForeground(Color.WHITE);
            BB1.setBounds(130,350,150,40);

            id15.add(BB1);

            B1.addActionListener(this);
            B3.addActionListener(this);
            B2.addActionListener(this);
            B4.addActionListener(this);
            BB1.addActionListener(this);

            f1.add(id15);
            f1.setVisible(true);
            f1.setSize(1300,750);
            f1.setLocation(10,10);

        }

    public void firstFirst(){
        try {
            FileChannel.open(Paths.get("output.txt"), StandardOpenOption.WRITE).truncate(0).close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        f2 = new JFrame("Race Details");
        f2.setBackground(Color.white);
        f2.setLayout(null);

        id16=new JLabel();
        id16.setBounds(10,10,1300,750);
        id16.setLayout(null);
        ImageIcon img = new ImageIcon("car3.jpg");
        id16.setIcon(img);


        B6 = new JButton("Add driver");
        B6.setBackground(Color.BLACK);
        B6.setForeground(Color.WHITE);
        B6.setBounds(50,150,150,40);

        id16.add(B6);

        B7=new JButton("Add Race");
        B7.setBackground(Color.BLACK);
        B7.setForeground(Color.WHITE);
        B7.setBounds(50,250,150,40);

        id16.add(B7);

        BB2 = new JButton("Back");
        BB2.setBackground(Color.BLACK);
        BB2.setForeground(Color.WHITE);
        BB2.setBounds(50,350,150,40);

        id16.add(BB2);

        B6.addActionListener(this);
        B7.addActionListener(this);
        BB2.addActionListener(this);


        f2.add(id16);
        f2.setVisible(true);
        f2.setSize(1300,750);
        f2.setLocation(10,10);

    }

    GUI() {
          firstpage();
    }


    public void actionPerformed(ActionEvent e) {

        if (e.getSource() == b) {
            f.setVisible(false);
            secondpage();
        }


        if (e.getSource() == B12){
            secondpage();
            f8.setVisible(false);
        }

        if (e.getSource() == B4){
            f1.setVisible(false);
            f7=new JFrame("Search Driver");
            f7.setSize(1280, 680);
            //Back button
            B14=new JButton("Back to Menu");
            f7.add(B14);
            B14.setBounds(1100,520,150,100);
            B14.setHorizontalTextPosition(SwingConstants.RIGHT);
            B14.addActionListener(this);
            f7.setVisible(true);
            JPanel JJ=new JPanel();
            t=new JTextField(16);
            B15 = new JButton("Submit");
            B15.setBounds(1100, 520, 150, 100);
            B15.setHorizontalTextPosition(SwingConstants.RIGHT);
            B15.addActionListener(this);
            f7.add(JJ);
            JJ.add(B15);
            JJ.add(t);
            Formula1ChampionshipManager ff=new Formula1ChampionshipManager();
            try {
                ff.SearchDriver2(t.getText());
            } catch (IOException ex) {
                ex.printStackTrace();
            }




        }
        if (e.getSource() == B2) {
            l3=new JLabel();
            f1.setVisible(false);
            f5 = new JFrame("Statistics");
            f5.setBackground(Color.white);
            B5= new JButton("Display Positions");
            B5.setBackground(Color.BLACK);
            B5.setForeground(Color.WHITE);
            B5.setBounds(50,150,150,40);

            l3.add(B5);

            B8=new JButton("Back");
            B8.setBackground(Color.BLACK);
            B8.setForeground(Color.WHITE);
            B8.setBounds(50,250,150,40);

            f5.add(B8);

            B5.addActionListener(this);
            B8.addActionListener(this);
            String filePath = "b.txt";
            File file = new File(filePath);

            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String[] columnsName = {"ID","Name","Location","Team","RacesNo","Points","FirstPositions","SecondPositions","ThirdPositions","Probability"};
                DefaultTableModel model;
                JTable jTable1 = new JTable();
                model = (DefaultTableModel)jTable1.getModel();
                model.setColumnIdentifiers(columnsName);
                // get lines from txt file
                Object[] tableLines = br.lines().toArray();

                // extract data from lines
                // set data to j table model
                for(int i = 0; i < tableLines.length; i++)
                {
                    String line = tableLines[i].toString().trim();
                    String[] dataRow = line.split(",");
                    model.addRow(dataRow);
                }
                f5.add(jTable1);
            } catch (IOException eww) {
                eww.printStackTrace();
            }
            f5.setVisible(true);
            f5.setSize(1300,750);
            f5.setLocation(10,10);
        }


        if (e.getSource() == B8) {
            f5.setVisible(false);
            f1.setVisible(true);
        }
        if (e.getSource() == B3) {
            f1.setVisible(false);
            f6 = new JFrame("Display");
            f6.setBackground(Color.white);

            B10=new JButton("Back");
            B10.setBackground(Color.BLACK);
            B10.setForeground(Color.WHITE);
            B10.setBounds(50,250,150,40);

            f6.add(B10);
            B10.addActionListener(this);
            String filePath = "abcc.txt";
            File file = new File(filePath);

            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String[] columnsName = {"ID","Name","Location","Team","RacesNo","Points","FirstPositions","SecondPositions","ThirdPositions"};
                DefaultTableModel model;
                JTable jTable1 = new JTable();
                model = (DefaultTableModel)jTable1.getModel();
                model.setColumnIdentifiers(columnsName);
                // get lines from txt file
                Object[] tableLines = br.lines().toArray();

                // extract data from lines
                // set data to j table model
                for(int i = 0; i < tableLines.length; i++)
                {
                    String line = tableLines[i].toString().trim();
                    String[] dataRow = line.split(",");
                    model.addRow(dataRow);
                }
                f6.add(jTable1);
            } catch (IOException eww) {
                eww.printStackTrace();
            }
            f6.setVisible(true);
            f6.setSize(1300,750);
            f6.setLocation(10,10);
        }


        if (e.getSource() == B5) {
            f5.dispose();

            f10=new JFrame("Positions");
            String filePath = "b.txt";
            File file = new File(filePath);
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String[] columnsName = {"ID","Name","Location","Team","RacesNo","Points","FirstPositions","SecondPositions","ThirdPositions","Probability"};
                DefaultTableModel model;
                JTable jTable1 = new JTable();
                model = (DefaultTableModel)jTable1.getModel();
                model.setColumnIdentifiers(columnsName);
                // get lines from txt file
                Object[] tableLines = br.lines().toArray();
                for(int i = 0; i < 3; i++)
                {
                    String line = tableLines[i].toString().trim();
                    String[] dataRow = line.split(",");
                    model.addRow(dataRow);
                }
                f10.add(jTable1);
            } catch (IOException eww) {
                eww.printStackTrace();
            }
            f10.setVisible(true);
            f10.setSize(1280,680);
            f10.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        }

        if (e.getSource() == B10) {
            f6.setVisible(false);
            secondpage();

            }

        if (e.getSource() == BB1) {
            f1.setVisible(false);
            f.setVisible(true);
        }

        if (e.getSource() == B9) {
            f9.setVisible(false);
            f2.setVisible(true);
        }
        if (e.getSource() == BB2) {
            f2.setVisible(false);
            f1.setVisible(true);
        }
        if (e.getSource() == B1) {
            f1.dispose();
            firstFirst();
        }

        if (e.getSource() == B6) {
            f2.dispose();
            Add_driver();
        }
        if (e.getSource() == B7) {
            f2.dispose();
            Add_Race();
        }
        if (e.getSource() == b0) {
            Formula1ChampionshipManager aa = new Formula1ChampionshipManager();
            try {
                BufferedWriter bw = new BufferedWriter(new FileWriter("output.txt", true));
                BufferedWriter bw2 = new BufferedWriter(new FileWriter("hh.txt", true));
                String name = t1.getText();
                String location = t2.getText();
                String team = t3.getText();
                aa.setName(name);
                aa.setLocation(location);
                aa.setTeam(team);
                aa.setRaces(aa.getNo_of_races());
                aa.setFirstpositions(aa.getFirstpositions());
                aa.setSecondpositions(aa.getSecondpositions());
                aa.setThirdpositions(aa.getThirdpositions());
                dri.add(aa);
                Formula1Driver d1 = new Formula1Driver(aa.getName(), aa.getLocation(), aa.getTeam(), aa.getTotalPoints(), aa.getNo_of_races(), aa.getFirstpositions(), aa.getSecondpositions(), aa.getThirdpositions());
                aa.list.add(d1);
                bw.write(d1.getName() + "," + d1.getLocation() + "," + d1.getTeam() + "," + d1.getTotalPoints() + "," + d1.getRaces() + "," + d1.getFirstpositions() + "," + d1.getSecondpositions() + "," + d1.getThirdpositions() + "," + d1.getTime() + "," + d1.getTime());
                bw2.write("Name : " + d1.getName() + "," + "Location : " + d1.getLocation() + "," + "Team : " + d1.getTeam() + "," + "Points : " + d1.getTotalPoints() + "," + "Races : " + d1.getRaces() + "," + "1sT: " + d1.getFirstpositions() + "," + "2nd : " + d1.getSecondpositions() + "," + "3rd : " + d1.getThirdpositions() + "," + "Time : " + d1.getTime());

                //bw2.write(String.valueOf(aa.list));
                bw.flush();
                bw.newLine();
                bw.close();
                bw2.flush();
                bw2.newLine();
                bw2.close();
                f2.setVisible(true);
                f4.setVisible(false);

            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        if (e.getSource() == b1) {
            f4.setVisible(false);
            f2.setVisible(true);
        }


        if (e.getSource() == b4) {
            JLabel ll=new JLabel();
            f3.dispose();
            f8 = new JFrame("Table");
            B12 = new JButton("Back");
            B12.setBounds(1100, 520, 150, 100);
            B12.setHorizontalTextPosition(SwingConstants.RIGHT);
            B12.addActionListener(this);
            ll.add(B12);
            f8.add(ll);
            f8.pack();
            f8.setSize(1280,680);
            f8.setVisible(true);
            Formula1ChampionshipManager ff3=new Formula1ChampionshipManager();
            String filePath = "output.txt";
            File file = new File(filePath);
            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String[] columnsName = {"Name","Location","Team","RacesNo","Points","FirstPositions","SecondPositions","ThirdPositions","Time"};
                DefaultTableModel model;
                JTable jTable1 = new JTable();
                model = (DefaultTableModel)jTable1.getModel();
                model.setColumnIdentifiers(columnsName);

                // get lines from txt file
                Object[] tableLines = br.lines().toArray();

                // extract data from lines
                // set data to j table model
                for(int i = 0; i < tableLines.length; i++)
                {
                    String line = tableLines[i].toString().trim();
                    String[] dataRow = line.split(",");
                    model.addRow(dataRow);
                }
                f8.add(jTable1);
            } catch (IOException eww) {
                eww.printStackTrace();
            }}


            if (e.getSource() == B14) {
                f7.setVisible(false);
                secondpage();
            }}
        public static void main(String...s)
    {
        new GUI();
    }}

