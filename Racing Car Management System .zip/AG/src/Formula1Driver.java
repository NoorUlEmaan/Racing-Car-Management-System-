import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Arrays;
import java.util.Scanner;

public class Formula1Driver extends Driver implements Serializable{
    private static int races;
    private int firstpositions;
    private int secondpositions;
    private int thirdpositions;
    private float probability;
    private int[] positionArray;
    private int points_per_race;
    private int totalPoints;
    public static int id=0;
    private String aa;
    public String fullArray="[ ";
    private Timestamp time;

    Scanner sc=new Scanner(System.in);


    //Constructors

    public Formula1Driver(String name, String location, String team,int points, int races, int firstpositions,int secondpositions,int thirdpositions) {
        super(name, location, team);
        this.firstpositions=firstpositions;
        this.secondpositions=secondpositions;
        this.thirdpositions=thirdpositions;
        this.totalPoints=points;
        id++;
    }



    public Formula1Driver() {
        id++;
    }

    public Formula1Driver(String name, String location, String team, int id) {
        super(name, location, team);
        id++;
    }

    //Getters and Setters

    public int getRaces() {
        return races;
    }

    public void setRaces(int races) {
        this.races = races;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    public double getProbability() {
        return probability;
    }

    public void setProbability(float probability) {
        this.probability = probability;
    }

    public int getFirstpositions() {
        return firstpositions;
    }

    public void setFirstpositions(int firstpositions) {
        this.firstpositions = firstpositions;
    }

    public int getSecondpositions() {
        return secondpositions;
    }

    public void setSecondpositions(int secondpositions) {
        this.secondpositions = secondpositions;
    }

    public int getThirdpositions() {
        return thirdpositions;
    }

    public void setThirdpositions(int thirdpositions) {
        this.thirdpositions = thirdpositions;
    }

    public int getPoints_per_race() {
        return points_per_race;
    }

    public void setPoints_per_race(int points_per_race) {
        this.points_per_race = points_per_race;
    }

    public int getTotalPoints() {
        return totalPoints;
    }

    public void setTotalPoints(int totalPoints) {
        this.totalPoints = totalPoints;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //ToString method


    @Override
    public String toString() {
        return " Name: " +getName() +
                ", Location: "+ getLocation()+", Team: "+getTeam() +
                ", Races: " + getRaces() + ", Points : "+getTotalPoints() +
                ", Firstpositions: " + getFirstpositions() +
                ", Secondpositions: " + getSecondpositions() +
                ", Thirdpositions: " + getThirdpositions() +","+ "Time : " + getTime();
    }


    public String toString2() {
        return " Name: " +getName() +
                ", Location: "+ getLocation()+", Team: "+getTeam() +
                ", Races: " + getRaces() + ", Points : "+getTotalPoints() +
                ", Firstpositions: " + getFirstpositions() +
                ", Secondpositions: " + getSecondpositions() +
                ", Thirdpositions: " + getThirdpositions() + " Probability : "+getProbability();
    }

    public String getPositionArray() {
        return aa;
    }
    public void getPointsWRTpositions(int i){
        System.out.println(positionArray[i]);
    }
    public void getFullArray(){
        for(int i=1;i<positionArray.length;i++){
            String a=i+":"+positionArray[i-1]+", ";
            fullArray+=a;
        }
        fullArray+=positionArray.length+":"+positionArray[positionArray.length-1];
        fullArray+=" ]";
        System.out.println(fullArray);
    }

    public void setPositionArray() {
        System.out.println("Enter the number of positions you want to show");
        int size=sc.nextInt();
        this.positionArray = new int[size];
        System.out.println("Enter your points from position 1 to position "+size+ " respectively");
        for (int i=0;i<size;i++){
            int a=sc.nextInt();
            this.positionArray[i]=a;
        }
        aa=Arrays.toString(positionArray);
    }
}